# StudyGrid Android App

This is a ready-to-open Android Studio project containing the StudyGrid PWA bundled as a local Android WebView app.

## Build the APK
1. Install Android Studio.
2. Open this `studygrid-android` folder.
3. Let Android Studio finish its setup/sync.
4. Choose **Build > Build App Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show the generated APK.

The app works from the bundled local files and does not require a web server.
